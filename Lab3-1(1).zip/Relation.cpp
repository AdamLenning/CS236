#include "Relation.h"

Relation::Relation(std::string name, Tuple scheme) {
	this->name = name;
	this->scheme = scheme;
}

void Relation::addTuple(Tuple t) {
	r.insert(t);
}

std::string Relation::toString() {

	std::string returnString;
	for (auto tuple : r) {
		for (unsigned i = 0; i < scheme.size(); i++) {
			returnString += scheme.at(i) + "=" + tuple.at(i) + ", ";
		}
		returnString.pop_back();
		returnString.pop_back();
		returnString += "\n";
	}
	return returnString;
}


void Relation::select1(std::string columnName, std::string stringMatch) {

	int columnIndex = scheme.getColumn(columnName);
	std::set<Tuple> newSet;
	for (auto t : r) {
		bool stringComp = (t.at(columnIndex) == stringMatch);
		if ((columnIndex != -1) && stringComp) {
			newSet.insert(t);
		}
	}
	r = newSet;
}

void Relation::select2(std::string columnName, std::string column2Name) {
	
	int column1Index = scheme.getColumn(columnName);
	int column2Index = scheme.getColumn(column2Name);

	std::set<Tuple> newSet;
	for (auto t : r) {
		if (t.at(column1Index) == t.at(column2Index)) {
			newSet.insert(t);
		}
	}
	r = newSet;
}

void Relation::project(std::vector<int> columns) {
	
	Tuple newScheme;
	for (unsigned i = 0; i < columns.size(); i++) {
		newScheme.push_back(scheme.at(columns.at(i)));
	}
	scheme = newScheme;

	std::set<Tuple> newSet;
	for (auto t : r) {
		Tuple newTuple;
		for (unsigned i = 0; i < columns.size(); i++) {
			newTuple.push_back(t.at(columns.at(i)));
		}
		newSet.insert(newTuple);
	}
	r = newSet;
}

void Relation::rename(std::string columnName, std::string newName) {
	for (unsigned i = 0; i < scheme.size(); i++) {
		if (scheme.at(i) == columnName) {
			scheme.at(i) = newName;
		}
	}
}

void Relation::query(Tuple tuplesToFind) {
	
	std::unordered_map<std::string, int> variablesSeen;

	//Perform the selects and mark what to keep for projects and rename
	for (unsigned i = 0; i < tuplesToFind.size(); i++) {
		if (tuplesToFind.at(i).at(0) == '\'') {
			select1(scheme.at(i), tuplesToFind.at(i));
		}
		else if (variablesSeen.find(tuplesToFind.at(i)) != variablesSeen.end()) { //If have seen the variable, the column where it was stored is in the map
			select2(scheme.at(variablesSeen.at(tuplesToFind.at(i))), scheme.at(i));
		}
		else variablesSeen.insert(std::pair<std::string, int>(tuplesToFind.at(i), i)); //adds to map if you haven't seen variable before
	}

	//Populate vectors for project and rename
	std::vector<int> projectList;
	std::vector<std::string> newNames;
	for (auto const& variable : variablesSeen) {
		newNames.push_back(variable.first);
		projectList.push_back(variable.second);
	}

	project(projectList);

	std::string returnString;
	for (auto tuple : r) {
		for (unsigned i = 0; i < scheme.size(); i++) {
			returnString += newNames.at(i) + "=" + tuple.at(i) + ", ";
		}
		returnString.pop_back();
		returnString.pop_back();
		returnString += "\n";
	}
	if (r.size() == 0) {
		std::cout << name << tuplesToFind.toString() << "? No" << std::endl;
	}
	else {
		std::cout << name << tuplesToFind.toString() << "? Yes(" << r.size() << ")" 
			<< std::endl << returnString;
	}
}