#ifndef RELATION_H
#define RELATION_H

#include "Tuple.h"
#include <set>
#include <unordered_map>
#include <iostream>

class Relation {
private:
	std::string name;
	Tuple scheme;
	std::set<Tuple> r;
public:
	Relation(std::string name, Tuple scheme);
	void addTuple(Tuple t);
	std::string toString();
	void select1(std::string columnName, std::string stringMatch);
	void select2(std::string columnName, std::string variable);
	void project(std::vector<int> columns);
	void rename(std::string columnName, std::string newName);
	void query(Tuple tuplesToFind);
};

#endif // !RELATION_H

