#include "Interpreter.h"

Interpreter::Interpreter(Parser* p) {
	parser = p; //This should be a parser that has already populated
	addRelations();
}

void Interpreter::addRelations() {
	std::vector<Predicate> schemes = parser->getSchemes();
	for (auto& scheme : schemes) {
		Relation* r = new Relation(scheme.getID(), Tuple(scheme.getParameters())); //This is a bit confusing, but I think I initialized everything right?
		database.insert(std::pair<std::string, Relation*>(scheme.getID(), r));
	}
}