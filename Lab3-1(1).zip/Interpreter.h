#ifndef INTERPRETER_H
#define INTERPRETER_H

#include <map>
#include "Relation.h"
#include "Parser.h"

class Interpreter {
private:
	std::map<std::string, Relation*> database;
	Parser* parser;
	void addRelations();

public:
	Interpreter(Parser* p);
};

#endif