#include "Lexer.cpp"
#include "Parser.h"

int main(int argc, char* argv[]) {
	ifstream ifs(argv[1]);
	string input((istreambuf_iterator<char>(ifs)),
		(istreambuf_iterator<char>()));

	Lexer lex(input);
	lex.generateTokens();

	Parser parser(lex.getTokens());
	parser.parse();

	return 0;
}